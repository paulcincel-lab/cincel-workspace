"use client";

import { useMemo, useSyncExternalStore } from "react";

import Avatar from "@/components/ui/Avatar";

function formatTodayLabel(): string {
  return new Intl.DateTimeFormat("es-MX", {
    weekday: "long",
    day: "numeric",
    month: "long",
    timeZone: "America/Mexico_City",
  }).format(new Date())
    .split(" ")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

export default function Header() {
  const isMounted = useSyncExternalStore(
    () => () => undefined,
    () => true,
    () => false
  );
  const todayLabel = useMemo(() => (isMounted ? formatTodayLabel() : ""), [isMounted]);

  return (
    <header className="mb-10">

      <div className="flex items-center gap-4">
        <Avatar name="Paul" showName={false} />

        <h1 className="text-xl font-bold text-slate-900">
          Bienvenido, Paul
        </h1>
      </div>

      <p className="mt-2 text-slate-800" suppressHydrationWarning>{todayLabel || "Cargando fecha..."}</p>

    </header>
  );
}